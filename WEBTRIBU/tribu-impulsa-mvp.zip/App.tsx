
import React, { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route, Navigate, useLocation, useNavigate, useParams } from 'react-router-dom';
import { Activity, Users, Settings, LogOut, User as UserIcon, CheckCircle, ArrowRight, Briefcase, Sparkles, MapPin, Globe, Instagram, Calendar, ArrowLeft, Bell, Edit2, Save, X } from 'lucide-react';
import { GlassCard } from './components/GlassCard';
import { WhatsAppFloat } from './components/WhatsAppFloat';
import { AFFINITY_OPTIONS, CATEGORY_MAPPING, MatchProfile } from './types';
import { generateMockMatches, getProfileById, getMockActivity, getMyProfile } from './services/matchService';

// --- Components defined here for file constraint compliance ---

// 1. Login / Landing
const LoginScreen = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen flex flex-col items-center justify-center px-4 text-center relative bg-[#022c22]">
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden -z-10">
        <div className="absolute top-[-10%] left-[-10%] w-[60%] h-[60%] rounded-full bg-emerald-800/30 blur-[100px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[60%] h-[60%] rounded-full bg-emerald-600/20 blur-[100px]" />
        {/* Golden glow */}
        <div className="absolute top-[40%] left-[40%] w-[30%] h-[30%] rounded-full bg-amber-500/10 blur-[80px] animate-pulse" />
        {/* Subtle texture overlay */}
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10 mix-blend-overlay"></div>
      </div>

      <GlassCard className="max-w-md w-full backdrop-blur-2xl bg-emerald-950/40 border-amber-500/20 shadow-[0_0_40px_rgba(0,0,0,0.5)]">
        <div className="mb-8 flex justify-center">
          <div className="w-24 h-24 bg-gradient-to-br from-emerald-400 to-teal-600 rounded-3xl flex items-center justify-center shadow-2xl rotate-3 border border-amber-400/30 relative">
            <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-amber-400/20 to-transparent rounded-3xl"></div>
            <Users className="text-white drop-shadow-lg" size={48} />
          </div>
        </div>
        <h1 className="text-5xl font-bold mb-3 tracking-tight text-transparent bg-clip-text bg-gradient-to-b from-amber-100 to-amber-400 drop-shadow-sm">Tribu Impulsa</h1>
        <p className="text-emerald-100/70 mb-10 font-light text-lg">
          Conecta, colabora y crece con el <span className="text-amber-400 font-normal">Algoritmo Tribal</span>.
        </p>
        
        <button 
          onClick={() => navigate('/register')}
          className="w-full bg-gradient-to-r from-amber-400 to-amber-600 text-emerald-950 py-4 rounded-2xl font-bold text-lg hover:shadow-[0_0_20px_rgba(251,191,36,0.4)] transition-all shadow-lg flex items-center justify-center gap-3 group border border-amber-300/50"
        >
          Ingresar con Shopify 
          <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform"/>
        </button>
        <p className="mt-8 text-[10px] text-emerald-100/30 uppercase tracking-[0.3em]">Acceso Exclusivo Miembros</p>
      </GlassCard>
    </div>
  );
};

// 2. Registration Wizard
const RegisterScreen = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: '',
    company: '',
    affinity: '',
    subcategory: ''
  });

  const handleNext = () => {
    if (step < 3) setStep(step + 1);
    else navigate('/dashboard');
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 py-12 bg-[#022c22] relative overflow-hidden">
       {/* Background blobs */}
       <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-b from-emerald-950 to-[#011c16]"></div>
       <div className="absolute top-20 left-[-100px] w-64 h-64 bg-emerald-500/10 rounded-full blur-[80px]"></div>
       <div className="absolute bottom-20 right-[-100px] w-64 h-64 bg-amber-500/10 rounded-full blur-[80px]"></div>

      <GlassCard className="max-w-lg w-full relative z-10 bg-emerald-900/30 border-emerald-500/20">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-2xl font-bold text-emerald-50">Registro Tribal</h2>
          <div className="flex gap-1.5">
            {[1, 2, 3].map(i => (
              <div key={i} className={`h-1.5 w-8 rounded-full transition-all duration-500 ${step >= i ? 'bg-amber-400 shadow-[0_0_8px_rgba(251,191,36,0.6)]' : 'bg-emerald-900/50'}`} />
            ))}
          </div>
        </div>

        {step === 1 && (
          <div className="space-y-6 animate-fadeIn">
            <div>
              <label className="block text-sm font-medium text-emerald-200/80 mb-2 uppercase tracking-wide text-xs">Nombre del Fundador</label>
              <input 
                type="text" 
                className="w-full bg-black/20 border border-emerald-500/20 rounded-xl p-4 text-emerald-50 placeholder-emerald-700/50 focus:outline-none focus:ring-1 focus:ring-amber-400/50 focus:border-amber-400/50 transition-all backdrop-blur-sm"
                placeholder="Ej. María Pérez"
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-emerald-200/80 mb-2 uppercase tracking-wide text-xs">Nombre del Emprendimiento</label>
              <input 
                type="text" 
                className="w-full bg-black/20 border border-emerald-500/20 rounded-xl p-4 text-emerald-50 placeholder-emerald-700/50 focus:outline-none focus:ring-1 focus:ring-amber-400/50 focus:border-amber-400/50 transition-all backdrop-blur-sm"
                placeholder="Ej. Cosmética Natural"
                value={formData.company}
                onChange={(e) => setFormData({...formData, company: e.target.value})}
              />
            </div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6 animate-fadeIn">
            <p className="text-sm text-emerald-200/60 font-light">Categoriza tu negocio para alimentar el mapa de calor del algoritmo.</p>
            <div>
              <label className="block text-sm font-medium text-emerald-200/80 mb-2 uppercase tracking-wide text-xs">Área de Afinidad</label>
              <div className="relative">
                <select 
                    className="w-full bg-black/20 border border-emerald-500/20 rounded-xl p-4 text-emerald-50 focus:outline-none focus:ring-1 focus:ring-amber-400/50 [&>option]:bg-emerald-900 appearance-none cursor-pointer"
                    value={formData.affinity}
                    onChange={(e) => setFormData({...formData, affinity: e.target.value, subcategory: ''})}
                >
                    <option value="">Selecciona una afinidad</option>
                    {AFFINITY_OPTIONS.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                </select>
                <div className="absolute right-4 top-1/2 transform -translate-y-1/2 pointer-events-none text-emerald-500">▼</div>
              </div>
            </div>
            
            {formData.affinity && (
              <div className="animate-slideUp">
                <label className="block text-sm font-medium text-emerald-200/80 mb-2 uppercase tracking-wide text-xs">Categoría Específica</label>
                <div className="relative">
                    <select 
                    className="w-full bg-black/20 border border-emerald-500/20 rounded-xl p-4 text-emerald-50 focus:outline-none focus:ring-1 focus:ring-amber-400/50 [&>option]:bg-emerald-900 appearance-none cursor-pointer"
                    value={formData.subcategory}
                    onChange={(e) => setFormData({...formData, subcategory: e.target.value})}
                    >
                    <option value="">Selecciona una categoría</option>
                    {CATEGORY_MAPPING[formData.affinity]?.map(opt => <option key={opt} value={opt}>{opt}</option>)}
                    </select>
                    <div className="absolute right-4 top-1/2 transform -translate-y-1/2 pointer-events-none text-emerald-500">▼</div>
                </div>
              </div>
            )}
          </div>
        )}

        {step === 3 && (
          <div className="text-center py-10 animate-fadeIn">
            <div className="w-24 h-24 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-6 border border-emerald-400/30 shadow-[0_0_30px_rgba(16,185,129,0.2)]">
              <CheckCircle size={48} className="text-emerald-400" />
            </div>
            <h3 className="text-3xl font-bold mb-3 text-white">¡Perfil Creado!</h3>
            <p className="text-emerald-200/70 max-w-xs mx-auto leading-relaxed font-light">
              El Algoritmo Tribal está analizando el ecosistema para encontrar tus primeros matches.
            </p>
          </div>
        )}

        <div className="mt-12 flex justify-end">
          <button 
            onClick={handleNext}
            className="bg-gradient-to-r from-emerald-500 to-emerald-700 hover:from-emerald-400 hover:to-emerald-600 text-white py-3 px-8 rounded-xl font-bold shadow-lg transition-all transform hover:scale-105 border border-emerald-400/30 flex items-center gap-2"
          >
            {step === 3 ? 'Ir a mi Panel' : 'Continuar'} <ArrowRight size={18} />
          </button>
        </div>
      </GlassCard>
    </div>
  );
};

// 3. My Profile View (Editable)
const MyProfileView = () => {
    const navigate = useNavigate();
    const [isEditing, setIsEditing] = useState(false);
    const [profile, setProfile] = useState(getMyProfile());

    const handleSave = () => {
        setIsEditing(false);
        // Logic to save to backend would go here
    };

    return (
        <div className="pb-32 animate-fadeIn min-h-screen bg-[#022c22]">
            {/* Header with Cover */}
            <div className="h-72 w-full relative">
                <img src={profile.coverUrl} alt="Cover" className="w-full h-full object-cover" />
                <div className="absolute inset-0 bg-gradient-to-b from-emerald-950/30 via-emerald-950/60 to-[#022c22]"></div>
                
                {/* Top Navigation Actions */}
                <div className="absolute top-6 left-6 z-30 flex items-center gap-4 w-full pr-12">
                    <button 
                        onClick={() => navigate('/dashboard')}
                        className="bg-black/40 backdrop-blur-md px-4 py-2 rounded-full text-white hover:bg-black/60 transition-colors border border-white/10 flex items-center gap-2"
                    >
                        <ArrowLeft size={18} />
                        <span className="text-sm font-medium">Volver</span>
                    </button>
                </div>
            </div>

            <div className="px-4 -mt-24 relative z-10">
                {/* 
                   FIX: Using standard Flex column layout.
                   The avatar is a child element that is pulled up with -mt-20.
                   The text follows naturally in the flow, pushed down by the avatar's height and margins.
                */}
                <GlassCard className="backdrop-blur-xl bg-emerald-900/60 !overflow-visible px-6 pb-8 border-t border-emerald-500/20 shadow-[0_-10px_40px_rgba(0,0,0,0.3)] flex flex-col items-center">
                    
                    {/* Avatar - Standard Block with Negative Margin */}
                    <div className="relative -mt-20 mb-6 group z-20">
                        <img 
                            src={profile.avatarUrl} 
                            alt={profile.name}
                            className="w-32 h-32 rounded-full border-4 border-[#022c22] shadow-2xl object-cover"
                        />
                        <div className="absolute bottom-0 right-0 bg-emerald-500 rounded-full p-2 border-4 border-[#022c22]">
                            <Edit2 size={14} className="text-white" />
                        </div>
                    </div>

                    {/* Main Info - Flows naturally after the avatar */}
                    <div className="text-center mb-8 w-full">
                        {isEditing ? (
                            <div className="space-y-2">
                                <input 
                                    value={profile.companyName} 
                                    onChange={(e) => setProfile({...profile, companyName: e.target.value})}
                                    className="bg-black/20 text-center text-2xl font-bold text-white rounded-lg p-1 w-full outline-none border border-emerald-500/30 focus:border-amber-400"
                                />
                                <input 
                                    value={profile.name} 
                                    onChange={(e) => setProfile({...profile, name: e.target.value})}
                                    className="bg-black/20 text-center text-emerald-200 font-medium text-lg rounded-lg p-1 w-full outline-none border border-emerald-500/30 focus:border-amber-400"
                                />
                            </div>
                        ) : (
                            <>
                                <h2 className="text-3xl font-bold text-white mb-1 tracking-tight">{profile.companyName}</h2>
                                <p className="text-emerald-300 font-medium text-lg">{profile.name}</p>
                            </>
                        )}
                        
                        <div className="flex justify-center gap-2 mt-4 flex-wrap">
                            <span className="text-xs font-semibold bg-gradient-to-r from-amber-500/20 to-amber-600/20 border border-amber-500/30 text-amber-200 px-4 py-1.5 rounded-full">
                                {profile.category}
                            </span>
                        </div>
                    </div>

                    {/* Actions */}
                    <div className="flex justify-end w-full mb-4">
                        {isEditing ? (
                            <div className="flex gap-2 ml-auto">
                                <button onClick={() => setIsEditing(false)} className="p-2 rounded-full bg-red-500/20 text-red-300"><X size={20}/></button>
                                <button onClick={handleSave} className="p-2 rounded-full bg-green-500/20 text-green-300"><Save size={20}/></button>
                            </div>
                        ) : (
                            <button onClick={() => setIsEditing(true)} className="text-xs flex items-center gap-1 text-emerald-300 hover:text-amber-400 transition-colors ml-auto">
                                <Edit2 size={14} /> Editar Perfil
                            </button>
                        )}
                    </div>

                    {/* Details */}
                    <div className="space-y-8 w-full text-left">
                        <div>
                            <h3 className="text-xs font-bold uppercase text-emerald-500/60 mb-3 tracking-[0.2em]">Biografía</h3>
                            {isEditing ? (
                                <textarea 
                                    value={profile.bio}
                                    onChange={(e) => setProfile({...profile, bio: e.target.value})}
                                    rows={4}
                                    className="w-full bg-black/20 text-emerald-100 rounded-lg p-3 outline-none border border-emerald-500/30 focus:border-amber-400"
                                />
                            ) : (
                                <p className="text-emerald-50/90 leading-relaxed text-lg font-light">
                                    {profile.bio}
                                </p>
                            )}
                        </div>

                        <div className="grid grid-cols-2 gap-4">
                            <div className="bg-emerald-950/30 p-4 rounded-2xl flex items-center gap-4 border border-emerald-500/10">
                            <div className="bg-emerald-500/10 p-2 rounded-lg text-emerald-400"><MapPin size={20} /></div>
                            <div className="text-sm">
                                <span className="block text-emerald-500/40 text-[10px] mb-0.5 uppercase tracking-wide">Ubicación</span>
                                <span className="font-medium text-white">{profile.location}</span>
                            </div>
                            </div>
                            <div className="bg-emerald-950/30 p-4 rounded-2xl flex items-center gap-4 border border-emerald-500/10">
                            <div className="bg-amber-500/10 p-2 rounded-lg text-amber-400"><Globe size={20} /></div>
                            <div className="text-sm">
                                <span className="block text-emerald-500/40 text-[10px] mb-0.5 uppercase tracking-wide">Web</span>
                                <span className="font-medium text-white truncate w-20">{profile.website}</span>
                            </div>
                            </div>
                        </div>

                        <div>
                            <h3 className="text-xs font-bold uppercase text-emerald-500/60 mb-3 tracking-[0.2em]">Etiquetas</h3>
                            <div className="flex flex-wrap gap-2">
                                {profile.tags.map(tag => (
                                <span key={tag} className="text-sm bg-emerald-800/30 border border-emerald-500/20 px-4 py-2 rounded-lg text-emerald-200 hover:bg-emerald-700/30 transition-colors">
                                    #{tag}
                                </span>
                                ))}
                                {isEditing && (
                                    <button className="text-sm border border-dashed border-emerald-500/40 px-4 py-2 rounded-lg text-emerald-400 hover:bg-emerald-900/50">
                                        + Agregar
                                    </button>
                                )}
                            </div>
                        </div>
                        
                        <div className="pt-6 border-t border-white/5">
                            <button 
                                onClick={() => navigate('/')} 
                                className="w-full py-3 rounded-xl border border-red-500/20 text-red-300 hover:bg-red-500/10 transition-colors flex items-center justify-center gap-2 text-sm"
                            >
                                <LogOut size={16} /> Cerrar Sesión
                            </button>
                        </div>
                    </div>
                </GlassCard>
            </div>
        </div>
    );
};

// 4. Full Profile Detail View (Other User)
const ProfileDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<MatchProfile | undefined>(undefined);

  useEffect(() => {
    if (id) {
      const p = getProfileById(id);
      setProfile(p);
    }
  }, [id]);

  if (!profile) return <div className="text-center mt-20 text-emerald-200">Cargando perfil...</div>;

  return (
    <div className="pb-24 animate-slideUp bg-[#022c22] min-h-screen">
      {/* Header / Cover Image */}
      <div className="h-72 w-full relative">
         <img src={profile.coverUrl} alt="Cover" className="w-full h-full object-cover" />
         <div className="absolute inset-0 bg-gradient-to-b from-emerald-950/40 via-transparent to-[#022c22]"></div>
         
         <button 
          onClick={() => navigate(-1)}
          className="absolute top-6 left-6 bg-black/40 backdrop-blur-md p-3 rounded-full text-white hover:bg-black/60 transition-colors z-20 border border-white/10"
        >
          <ArrowLeft size={20} />
        </button>
      </div>
      
      <div className="px-4 -mt-20 relative z-10">
        {/* 
            FIX: Flexbox layout for perfect avatar alignment.
            !overflow-visible ensures the avatar top isn't clipped.
            -mt-20 pulls the avatar up.
            mb-6 pushes the text down.
        */}
        <GlassCard className="backdrop-blur-xl bg-emerald-900/60 !overflow-visible px-6 pb-8 border-t border-emerald-500/20 shadow-[0_-10px_40px_rgba(0,0,0,0.3)] flex flex-col items-center">
           
           {/* Avatar & Logo Composition - Standard Block */}
           <div className="relative -mt-20 mb-6 z-20">
              <div className="relative">
                <img 
                    src={profile.avatarUrl} 
                    alt={profile.name}
                    className="w-32 h-32 rounded-full border-4 border-[#022c22] shadow-2xl object-cover"
                />
                <div className="absolute -bottom-1 -right-1 bg-[#022c22] rounded-full p-1.5">
                    <img 
                        src={profile.companyLogoUrl} 
                        alt="Logo"
                        className="w-10 h-10 rounded-full bg-emerald-50 backdrop-blur border border-white/20"
                    />
                </div>
             </div>
           </div>

           {/* Main Info - Flows naturally */}
           <div className="text-center mb-8 w-full">
             <h2 className="text-3xl font-bold text-white mb-1 tracking-tight">{profile.companyName}</h2>
             <p className="text-emerald-300 font-medium text-lg">{profile.name}</p>
             <div className="flex justify-center gap-2 mt-4 flex-wrap">
               <span className="text-xs font-semibold bg-gradient-to-r from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 px-4 py-1.5 rounded-full text-emerald-100">
                 {profile.category}
               </span>
               <span className="text-xs font-semibold bg-amber-500/10 border border-amber-500/30 px-4 py-1.5 rounded-full text-amber-200">
                 {profile.subCategory}
               </span>
             </div>
           </div>

           <div className="space-y-8 w-full text-left">
             <div>
               <h3 className="text-xs font-bold uppercase text-emerald-500/60 mb-3 tracking-[0.2em]">Sobre Nosotros</h3>
               <p className="text-emerald-50/90 leading-relaxed text-lg font-light">
                 {profile.bio}
               </p>
             </div>

             <div className="grid grid-cols-2 gap-4">
                <div className="bg-emerald-950/30 p-4 rounded-2xl flex items-center gap-4 border border-emerald-500/10">
                   <div className="bg-emerald-500/10 p-2 rounded-lg text-emerald-400"><MapPin size={20} /></div>
                   <div className="text-sm">
                      <span className="block text-emerald-500/40 text-[10px] mb-0.5 uppercase tracking-wide">Ubicación</span>
                      <span className="font-medium text-white">{profile.location}</span>
                   </div>
                </div>
                <div className="bg-emerald-950/30 p-4 rounded-2xl flex items-center gap-4 border border-emerald-500/10">
                   <div className="bg-emerald-500/10 p-2 rounded-lg text-emerald-400"><Calendar size={20} /></div>
                   <div className="text-sm">
                      <span className="block text-emerald-500/40 text-[10px] mb-0.5 uppercase tracking-wide">Fundada</span>
                      <span className="font-medium text-white">{profile.foundingYear}</span>
                   </div>
                </div>
             </div>

             <div>
                <h3 className="text-xs font-bold uppercase text-emerald-500/60 mb-3 tracking-[0.2em]">Enlaces</h3>
                <div className="flex flex-col gap-3">
                  <a href="#" className="flex items-center gap-4 text-emerald-100 hover:text-white transition-colors bg-emerald-950/30 p-4 rounded-2xl border border-emerald-500/10 group">
                    <Globe size={20} className="text-blue-400 group-hover:scale-110 transition-transform"/> 
                    <span className="font-medium text-sm">{profile.website}</span>
                  </a>
                  <a href="#" className="flex items-center gap-4 text-emerald-100 hover:text-white transition-colors bg-emerald-950/30 p-4 rounded-2xl border border-emerald-500/10 group">
                    <Instagram size={20} className="text-pink-400 group-hover:scale-110 transition-transform"/> 
                    <span className="font-medium text-sm">{profile.instagram}</span>
                  </a>
                </div>
             </div>

             <div>
               <h3 className="text-xs font-bold uppercase text-emerald-500/60 mb-3 tracking-[0.2em]">Skills</h3>
               <div className="flex flex-wrap gap-2">
                 {profile.tags.map(tag => (
                   <span key={tag} className="text-sm bg-emerald-800/30 border border-emerald-500/20 px-4 py-2 rounded-lg text-emerald-200 hover:bg-emerald-700/30 transition-colors">
                     #{tag}
                   </span>
                 ))}
               </div>
             </div>

             <button className="w-full bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-4 rounded-xl shadow-[0_0_20px_rgba(16,185,129,0.4)] transition-all flex items-center justify-center gap-3 transform hover:scale-[1.02] border border-emerald-400/20">
               <img src="https://upload.wikimedia.org/wikipedia/commons/6/6b/WhatsApp.svg" className="w-6 h-6 filter invert brightness-200" alt="ws"/>
               Contactar por WhatsApp
             </button>
           </div>
        </GlassCard>
      </div>
    </div>
  );
};

// 5. Activity View
const ActivityView = () => {
  const activities = getMockActivity();

  return (
    <div className="pb-32 animate-fadeIn min-h-screen bg-[#022c22]">
      <header className="px-6 py-6 sticky top-0 z-30 backdrop-blur-xl bg-[#022c22]/80 border-b border-emerald-500/10">
        <h1 className="text-2xl font-bold flex items-center gap-2 text-emerald-50 tracking-tight">
          <Bell className="text-amber-400 fill-amber-400/20" /> Actividad Tribal
        </h1>
      </header>
      
      <div className="px-4 py-4 space-y-4">
        {activities.map((item) => (
          <GlassCard key={item.id} padding="p-5" className="flex gap-5 items-start group hover:bg-emerald-800/30 transition-colors border-emerald-500/10 bg-emerald-900/20">
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-inner ${
               item.type === 'match' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
               item.type === 'system' ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' :
               'bg-teal-500/10 text-teal-400 border border-teal-500/20'
            }`}>
              {item.type === 'match' ? <Sparkles size={20} /> : <Activity size={20} />}
            </div>
            <div className="flex-1 pt-1">
              <div className="flex justify-between items-start mb-1">
                 <h3 className="font-bold text-emerald-50 text-base">{item.title}</h3>
                 <span className="text-[10px] text-emerald-400/60 uppercase tracking-wide bg-emerald-950/50 px-2 py-1 rounded border border-emerald-500/10">{item.timestamp}</span>
              </div>
              <p className="text-sm text-emerald-200/60 leading-relaxed">{item.description}</p>
            </div>
            {!item.isRead && (
              <div className="w-2 h-2 bg-amber-500 rounded-full mt-3 shadow-[0_0_10px_rgba(245,158,11,0.5)]"></div>
            )}
          </GlassCard>
        ))}
      </div>
    </div>
  );
};

// 6. Dashboard (Matches)
const Dashboard = () => {
  const navigate = useNavigate();
  const matches = generateMockMatches("Bienestar y Salud"); 
  // Use current user profile for icon
  const myProfile = getMyProfile();

  return (
    <div className="pb-32 animate-fadeIn min-h-screen bg-[#022c22]">
      {/* Header */}
      <header className="px-6 py-6 flex justify-between items-center bg-gradient-to-b from-[#022c22] to-transparent sticky top-0 z-30 backdrop-blur-md">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Hola, {myProfile.name.split(' ')[0]}</h1>
          <p className="text-emerald-200/60 text-sm">Tus conexiones activas para hoy</p>
        </div>
        <div 
          onClick={() => navigate('/my-profile')}
          className="w-12 h-12 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 p-[2px] cursor-pointer hover:scale-105 transition-transform shadow-[0_0_15px_rgba(251,191,36,0.3)]"
        >
           <img 
            src={myProfile.avatarUrl} 
            alt="Me"
            className="w-full h-full rounded-full object-cover border-2 border-[#022c22]"
           />
        </div>
      </header>

      {/* Stats */}
      <div className="px-4 mb-8">
        <GlassCard className="flex items-center justify-between bg-gradient-to-r from-emerald-900/60 to-teal-900/60 border-emerald-500/20 shadow-lg">
          <div className="text-center flex-1">
            <p className="text-[10px] text-emerald-400 uppercase tracking-wider mb-1 font-semibold">Match Rate</p>
            <p className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-emerald-300 to-teal-300">85%</p>
          </div>
          <div className="h-10 w-[1px] bg-emerald-500/20"></div>
          <div className="text-center flex-1">
            <p className="text-[10px] text-emerald-400 uppercase tracking-wider mb-1 font-semibold">Conexiones</p>
            <p className="text-3xl font-bold text-white">{matches.length}</p>
          </div>
          <div className="h-10 w-[1px] bg-emerald-500/20"></div>
          <div className="text-center flex-1 flex flex-col items-center justify-center">
             <div className="flex items-center gap-1 text-amber-400 mb-1">
                <Activity size={16} />
                <span className="text-xs font-bold">Alta</span>
             </div>
             <p className="text-[10px] text-emerald-500/60">Actividad</p>
          </div>
        </GlassCard>
      </div>

      {/* Matches List */}
      <div className="px-4">
        <h2 className="text-lg font-semibold mb-5 flex items-center gap-2 text-emerald-50">
          <Sparkles size={18} className="text-amber-400 fill-amber-400/40"/> 
          Tus Matches Recomendados
        </h2>
        
        <div className="space-y-5">
          {matches.map((match) => (
            <GlassCard key={match.id} padding="p-0" className="hover:bg-emerald-900/40 transition-all duration-300 group border-emerald-500/10 hover:border-amber-500/30 bg-emerald-900/20">
              <div className="p-5">
                <div className="flex gap-4 mb-4">
                    {/* Avatar + Logo overlapping */}
                    <div className="relative flex-shrink-0">
                        <img 
                        src={match.targetProfile.avatarUrl} 
                        alt={match.targetProfile.name} 
                        className="w-16 h-16 rounded-2xl object-cover border border-emerald-500/20 shadow-lg"
                        />
                        <div className="absolute -bottom-2 -right-2 w-8 h-8 bg-emerald-950 backdrop-blur rounded-lg border border-emerald-500/30 p-0.5">
                            <img src={match.targetProfile.companyLogoUrl} alt="logo" className="w-full h-full rounded-md opacity-90"/>
                        </div>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start mb-1">
                            <h3 className="font-bold text-lg leading-tight text-emerald-50 truncate pr-2">{match.targetProfile.companyName}</h3>
                            <span className={`text-xs font-bold px-2 py-1 rounded-full border flex-shrink-0 ${
                                match.affinityScore > 90 ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' : 'bg-amber-500/10 text-amber-400 border-amber-500/20'
                            }`}>
                            {match.affinityScore}%
                            </span>
                        </div>
                        <p className="text-sm text-emerald-200/60 truncate mb-2">{match.targetProfile.name}</p>
                        <div className="flex items-center gap-2 flex-wrap">
                            <span className="text-[10px] bg-emerald-500/10 px-2 py-0.5 rounded text-emerald-300 border border-emerald-500/20 truncate max-w-[120px]">
                                {match.targetProfile.category}
                            </span>
                            <span className="text-[10px] bg-teal-500/10 px-2 py-0.5 rounded text-teal-300 border border-teal-500/20 truncate max-w-[120px]">
                                {match.targetProfile.subCategory}
                            </span>
                        </div>
                    </div>
                </div>
                
                <div className="pt-4 border-t border-emerald-500/10 flex items-center justify-between">
                    <div className="flex items-center gap-2 text-emerald-400/50 text-xs">
                        <Briefcase size={14} />
                        <span className="italic">{match.reason}</span>
                    </div>
                    <button 
                      onClick={() => navigate(`/profile/${match.targetProfile.id}`)}
                      className="text-xs font-bold bg-emerald-100 text-emerald-900 px-4 py-2 rounded-lg hover:bg-white transition-colors shadow-lg flex items-center gap-1"
                    >
                      Ver Perfil <ArrowRight size={12}/>
                    </button>
                </div>
              </div>
            </GlassCard>
          ))}
        </div>
      </div>
    </div>
  );
};

// Main Layout with Navigation
const AppLayout = () => {
  const location = useLocation();
  const navigate = useNavigate();
  
  // Hide nav on login and register pages
  const showNav = !['/', '/register'].includes(location.pathname);
  const isDashboard = location.pathname.includes('/dashboard');
  const isActivity = location.pathname.includes('/activity');
  const isProfile = location.pathname.includes('/my-profile');

  return (
    <div className="min-h-screen w-full text-emerald-50 font-sans relative bg-[#022c22]">
        {/* Ambient Background Mesh - Deep Emerald & Gold */}
        <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
            <div className="absolute top-[-20%] left-[20%] w-[800px] h-[800px] bg-emerald-800/10 rounded-full blur-[120px] mix-blend-screen animate-pulse duration-[10s]"></div>
            <div className="absolute bottom-[-20%] right-[20%] w-[600px] h-[600px] bg-amber-600/5 rounded-full blur-[100px] mix-blend-screen"></div>
        </div>
        
        <div className="relative z-10">
            <Routes>
                <Route path="/" element={<LoginScreen />} />
                <Route path="/register" element={<RegisterScreen />} />
                <Route path="/dashboard" element={<Dashboard />} />
                <Route path="/activity" element={<ActivityView />} />
                <Route path="/profile/:id" element={<ProfileDetail />} />
                <Route path="/my-profile" element={<MyProfileView />} />
                <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
        </div>

        {showNav && (
          <nav className="fixed bottom-0 left-0 w-full bg-[#022c22]/90 backdrop-blur-xl border-t border-emerald-500/10 py-2 px-8 flex justify-around items-center z-40 pb-safe h-[80px]">
            
            {/* Dashboard Button */}
            <button 
              onClick={() => navigate('/dashboard')}
              className={`flex flex-col items-center transition-all duration-300 w-16 ${isDashboard ? 'text-emerald-400 scale-105' : 'text-emerald-600 hover:text-emerald-300'}`}
            >
              <Users size={24} strokeWidth={isDashboard ? 2.5 : 2} />
              <span className="text-[10px] mt-1 font-medium">Tribu</span>
            </button>
            
            {/* Center Action Button (Does not cover content, links to Activity or special feature) */}
            <div className="relative -top-6">
                 <button 
                    onClick={() => navigate('/activity')}
                    className="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-full flex items-center justify-center border-4 border-[#022c22] shadow-[0_0_20px_rgba(245,158,11,0.3)] transition-transform hover:scale-105"
                >
                    <Bell size={28} className="text-[#022c22] fill-[#022c22]/20" />
                </button>
            </div>

            {/* Profile/Activity Button (Redundant activity link removed, simplified to Profile or Settings) */}
            <button 
              onClick={() => navigate('/my-profile')}
              className={`flex flex-col items-center transition-all duration-300 w-16 ${isProfile ? 'text-emerald-400 scale-105' : 'text-emerald-600 hover:text-emerald-300'}`}
            >
              <Settings size={24} strokeWidth={isProfile ? 2.5 : 2} />
              <span className="text-[10px] mt-1 font-medium">Perfil</span>
            </button>
          </nav>
        )}
        
        {showNav && <WhatsAppFloat />}
    </div>
  );
};

const App = () => {
  return (
    <Router>
      <AppLayout />
    </Router>
  );
};

export default App;
