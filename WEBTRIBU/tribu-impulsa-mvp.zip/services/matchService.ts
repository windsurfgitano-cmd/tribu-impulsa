import { Match, MatchProfile, AFFINITY_OPTIONS, CATEGORY_MAPPING, ActivityItem } from '../types';

// Gender-separated names for realistic avatars
const MALE_NAMES = ["Carlos", "Felipe", "Jorge", "Diego", "Luis", "Javier", "Ricardo", "Matias", "Pablo", "Andres", "Jose", "Manuel", "Cristian", "Nicolas", "Fernando"];
const FEMALE_NAMES = ["Ana", "Maria", "Sofia", "Valentina", "Camila", "Fernanda", "Isabel", "Gabriela", "Daniela", "Constanza", "Carolina", "Francisca", "Catalina", "Javiera", "Paula"];
const LAST_NAMES = ["Gonzalez", "Muñoz", "Rojas", "Diaz", "Perez", "Soto", "Contreras", "Silva", "Martinez", "Sepulveda", "Morales", "Rodriguez", "Lopez", "Fuentes", "Hernandez", "Torres", "Araya", "Flores", "Espinoza", "Valenzuela"];

const COMPANY_SUFFIXES = ["SpA", "Ltda", "Consultores", "Studio", "Lab", "Creativos", "Chile", "Group", "Solutions", "Design", "Eco", "Tech", "Global", "Market"];
const COMPANY_PREFIXES = ["Nova", "Impulsa", "Eco", "Crea", "Visual", "Smart", "Bio", "Tecno", "Innova", "Tribu", "Alpha", "Omega", "Red", "Blue", "Green", "Aura", "Zen", "Vital"];
const CITIES = ["Santiago", "Valparaíso", "Concepción", "La Serena", "Temuco", "Antofagasta", "Puerto Varas", "Viña del Mar", "Providencia", "Las Condes", "Vitacura", "Ñuñoa"];

const BIO_TEMPLATES = [
  "Ayudamos a nuestros clientes a conectar con su propósito a través de productos de {subcategory} de alta calidad.",
  "Somos una empresa líder en {category} enfocada en soluciones innovadoras para el mercado chileno.",
  "Dedicados a la excelencia en {subcategory}, buscamos alianzas estratégicas para expandir nuestro impacto.",
  "Transformamos el sector de {category} con un enfoque sustentable y centrado en el usuario.",
  "Expertos en {subcategory} con más de 5 años de experiencia en el ecosistema emprendedor.",
  "Creando el futuro de {subcategory} desde Chile para el mundo."
];

// Unsplash Image IDs mapped by category for pretty covers - Updated for Emerald/Nature/Gold feel
const COVER_IMAGES: Record<string, string[]> = {
  "Bienestar y Salud": ["1502082553048-f009c37129b9", "1544367563-121cf674e6cd", "1498837167922-9dd653618197"], // Nature, Forest, Spa
  "Diseño y Estilo": ["1507652319164-999906626d17", "1496293455970-f8581aae0e3c", "1550614000-4b9519e02eb3"], // Texture, Cloth, Gold
  "Digital y Tecnología": ["1451187580459-43490279c0fa", "1518770660439-4636190af475", "1550751827-4bd374c3f58b"], // Circuit, Dark tech
  "Sustentabilidad": ["1470058869958-2a77ade41c02", "1500382017468-9049fed747ef", "1466692476868-aef1dfb1e735"], // Leaves, Forest, Green
  "Servicios Profesionales": ["1486406146926-c627a92ad1ab", "1497215728101-856f4ea42174", "1454165804606-c3d57bc86b40"], // Architecture, Office
  "Estilo de Vida y Experiencias": ["1542204165-65bf26472b9b", "1533174072545-a8f67f0c536c", "1516455594145-63344849c22d"], // Hiking, Travel, Food
  "default": ["1518531933871-296adeb54dd0", "1475924156734-496f6cac6ec1", "1550684848-fac1c5b4e853"] // Forest mist, textures
};

const getRandomCover = (category: string): string => {
  const ids = COVER_IMAGES[category] || COVER_IMAGES["default"];
  const id = ids[Math.floor(Math.random() * ids.length)];
  return `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=800&q=80`;
};

// Generator function for 1 profile
const generateRandomProfile = (id: string): MatchProfile => {
  const isFemale = Math.random() > 0.5;
  const names = isFemale ? FEMALE_NAMES : MALE_NAMES;
  const firstName = names[Math.floor(Math.random() * names.length)];
  const lastName = LAST_NAMES[Math.floor(Math.random() * LAST_NAMES.length)];
  
  const category = AFFINITY_OPTIONS[Math.floor(Math.random() * AFFINITY_OPTIONS.length)];
  const subCategories = CATEGORY_MAPPING[category] || ["General"];
  const subCategory = subCategories[Math.floor(Math.random() * subCategories.length)];
  
  const companyName = `${COMPANY_PREFIXES[Math.floor(Math.random() * COMPANY_PREFIXES.length)]} ${COMPANY_SUFFIXES[Math.floor(Math.random() * COMPANY_SUFFIXES.length)]}`;
  const city = CITIES[Math.floor(Math.random() * CITIES.length)];
  
  const bioTemplate = BIO_TEMPLATES[Math.floor(Math.random() * BIO_TEMPLATES.length)];
  const bio = bioTemplate.replace("{category}", category).replace("{subcategory}", subCategory);

  // Realistic Avatar
  const genderParam = isFemale ? 'women' : 'men';
  const avatarId = Math.floor(Math.random() * 70); 
  const avatarUrl = `https://randomuser.me/api/portraits/${genderParam}/${avatarId}.jpg`;

  // Abstract Company Logo (Dicebear Shapes) - Using emerald/gold colors via URL params
  const companyLogoUrl = `https://api.dicebear.com/9.x/shapes/svg?seed=${companyName.replace(/\s/g, '')}&backgroundColor=transparent`;

  return {
    id,
    name: `${firstName} ${lastName}`,
    companyName: companyName,
    category,
    subCategory,
    avatarUrl,
    companyLogoUrl,
    coverUrl: getRandomCover(category),
    whatsapp: `569${Math.floor(Math.random() * 90000000 + 10000000)}`,
    location: city,
    website: `www.${companyName.toLowerCase().replace(/\s/g, '')}.cl`,
    instagram: `@${companyName.toLowerCase().replace(/\s/g, '')}_cl`,
    bio: bio,
    foundingYear: Math.floor(Math.random() * (2024 - 2018) + 2018),
    tags: [category.split(' ')[0], subCategory, "B2B", "Innovación", "Emprendimiento"].slice(0, Math.floor(Math.random() * 3) + 2)
  };
};

// Generate 100 users once
const DUMMY_DATABASE: MatchProfile[] = Array.from({ length: 100 }, (_, i) => 
  generateRandomProfile(`user-${i + 1}`)
);

export const getProfileById = (id: string): MatchProfile | undefined => {
  return DUMMY_DATABASE.find(p => p.id === id);
};

// Simulates the logged in user
export const getMyProfile = (): MatchProfile => {
    // Returning a fixed profile for the "Me" view, simulating state
    const profile = DUMMY_DATABASE[0];
    return {
        ...profile,
        name: "Usuario Fundador",
        companyName: "Mi Empresa",
        bio: "Este es mi perfil editable. Busco conectar con proveedores de logística y diseño.",
        category: "Bienestar y Salud"
    };
}

export const generateMockMatches = (userCategory: string): Match[] => {
  const numberOfMatches = Math.floor(Math.random() * 5) + 8; 
  // Exclude index 0 (My Profile)
  const shuffled = [...DUMMY_DATABASE.slice(1)].sort(() => 0.5 - Math.random());
  const selectedProfiles = shuffled.slice(0, numberOfMatches);

  return selectedProfiles.map(profile => {
    let reason = "Afinidad general detectada";
    const score = Math.floor(Math.random() * (99 - 70) + 70);

    if (userCategory === profile.category) {
      reason = "Pares en la misma industria";
    } else if (userCategory === "Bienestar y Salud" && profile.category === "Digital y Tecnología") {
      reason = "Oportunidad: Digitalización";
    } else if (userCategory === "Diseño y Estilo" && profile.category === "Industria y Manufactura") {
      reason = "Oportunidad: Proveedores";
    } else if (profile.category === "Servicios Profesionales") {
      reason = "Soporte recomendado";
    } else {
      reason = "Sinergia comercial potencial";
    }

    return {
      id: `match-${profile.id}`,
      targetProfile: profile,
      affinityScore: score,
      reason: reason,
      status: 'New'
    };
  });
};

export const getMockActivity = (): ActivityItem[] => {
  return [
    {
      id: '1',
      type: 'system',
      title: 'Algoritmo Calibrado',
      description: 'Hemos afinado tus preferencias de afinidad basado en tus últimas interacciones.',
      timestamp: 'Hace 2 horas',
      isRead: false
    },
    {
      id: '2',
      type: 'match',
      title: 'Match de Oro',
      description: 'EcoTech Solutions tiene un 98% de compatibilidad contigo.',
      timestamp: 'Hace 5 horas',
      isRead: false
    },
    {
      id: '3',
      type: 'view',
      title: 'Te están viendo',
      description: '3 empresas han revisado tu perfil esta semana.',
      timestamp: 'Ayer',
      isRead: true
    },
    {
      id: '4',
      type: 'update',
      title: 'Tendencia Global',
      description: 'El rubro "Bienestar" está buscando más proveedores digitales este mes.',
      timestamp: 'Hace 2 días',
      isRead: true
    }
  ];
};